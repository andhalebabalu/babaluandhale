/* ============================================================
   SplashCursor.js — Vanilla JS port of the SplashCursor React component
   WebGL fluid simulation cursor effect (React Bits)
   ============================================================ */

(function () {
  'use strict';

  function initSplashCursor(options) {
    const config = Object.assign({
      SIM_RESOLUTION:      128,
      DYE_RESOLUTION:      1440,
      CAPTURE_RESOLUTION:  512,
      DENSITY_DISSIPATION: 3.5,
      VELOCITY_DISSIPATION: 2,
      PRESSURE:            0.1,
      PRESSURE_ITERATIONS: 20,
      CURL:                3,
      SPLAT_RADIUS:        0.2,
      SPLAT_FORCE:         6000,
      SHADING:             true,
      COLOR_UPDATE_SPEED:  10,
      PAUSED:              false,
      BACK_COLOR:          { r: 0.5, g: 0, b: 0 },
      TRANSPARENT:         true,
      RAINBOW_MODE:        true,
      COLOR:               '#ff0000'
    }, options || {});

    /* ── DOM setup ── */
    const container = document.createElement('div');
    container.style.cssText =
      'position:fixed;top:0;left:0;z-index:50;pointer-events:none;width:100%;height:100%;';
    const canvas = document.createElement('canvas');
    canvas.id    = 'fluid-cursor';
    canvas.style.cssText = 'width:100vw;height:100vh;display:block;';
    container.appendChild(canvas);
    document.body.appendChild(container);

    /* ── Pointer prototype ── */
    function PointerPrototype() {
      this.id           = -1;
      this.texcoordX    = 0;
      this.texcoordY    = 0;
      this.prevTexcoordX = 0;
      this.prevTexcoordY = 0;
      this.deltaX       = 0;
      this.deltaY       = 0;
      this.down         = false;
      this.moved        = false;
      this.color        = [0, 0, 0];
    }

    let pointers = [new PointerPrototype()];
    let animFrameId = null;

    /* ── WebGL context ── */
    const { gl, ext } = getWebGLContext(canvas);
    if (!ext.supportLinearFiltering) {
      config.DYE_RESOLUTION = 256;
      config.SHADING        = false;
    }

    function getWebGLContext(canvas) {
      const params = { alpha: true, depth: false, stencil: false, antialias: false, preserveDrawingBuffer: false };
      let gl = canvas.getContext('webgl2', params);
      const isWebGL2 = !!gl;
      if (!isWebGL2) {
        gl = canvas.getContext('webgl', params) || canvas.getContext('experimental-webgl', params);
      }
      let halfFloat, supportLinearFiltering;
      if (isWebGL2) {
        gl.getExtension('EXT_color_buffer_float');
        supportLinearFiltering = gl.getExtension('OES_texture_float_linear');
      } else {
        halfFloat              = gl.getExtension('OES_texture_half_float');
        supportLinearFiltering = gl.getExtension('OES_texture_half_float_linear');
      }
      gl.clearColor(0, 0, 0, 1);
      const halfFloatTexType = isWebGL2
        ? gl.HALF_FLOAT
        : (halfFloat && halfFloat.HALF_FLOAT_OES);
      let formatRGBA, formatRG, formatR;
      if (isWebGL2) {
        formatRGBA = getSupportedFormat(gl, gl.RGBA16F, gl.RGBA, halfFloatTexType);
        formatRG   = getSupportedFormat(gl, gl.RG16F,   gl.RG,   halfFloatTexType);
        formatR    = getSupportedFormat(gl, gl.R16F,    gl.RED,  halfFloatTexType);
      } else {
        formatRGBA = getSupportedFormat(gl, gl.RGBA, gl.RGBA, halfFloatTexType);
        formatRG   = getSupportedFormat(gl, gl.RGBA, gl.RGBA, halfFloatTexType);
        formatR    = getSupportedFormat(gl, gl.RGBA, gl.RGBA, halfFloatTexType);
      }
      return { gl, ext: { formatRGBA, formatRG, formatR, halfFloatTexType, supportLinearFiltering } };
    }

    function getSupportedFormat(gl, internalFormat, format, type) {
      if (!supportRenderTextureFormat(gl, internalFormat, format, type)) {
        switch (internalFormat) {
          case gl.R16F:  return getSupportedFormat(gl, gl.RG16F,   gl.RG,   type);
          case gl.RG16F: return getSupportedFormat(gl, gl.RGBA16F, gl.RGBA, type);
          default:       return null;
        }
      }
      return { internalFormat, format };
    }

    function supportRenderTextureFormat(gl, internalFormat, format, type) {
      const tex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, internalFormat, 4, 4, 0, format, type, null);
      const fbo = gl.createFramebuffer();
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
      return gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
    }

    /* ── Shader / Program helpers ── */
    function compileShader(type, source, keywords) {
      source = addKeywords(source, keywords);
      const shader = gl.createShader(type);
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS))
        console.warn(gl.getShaderInfoLog(shader));
      return shader;
    }

    function addKeywords(source, keywords) {
      if (!keywords) return source;
      return keywords.map(k => '#define ' + k + '\n').join('') + source;
    }

    function createProgram(vs, fs) {
      const prog = gl.createProgram();
      gl.attachShader(prog, vs);
      gl.attachShader(prog, fs);
      gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS))
        console.warn(gl.getProgramInfoLog(prog));
      return prog;
    }

    function getUniforms(program) {
      const uniforms = [];
      const count = gl.getProgramParameter(program, gl.ACTIVE_UNIFORMS);
      for (let i = 0; i < count; i++) {
        const name = gl.getActiveUniform(program, i).name;
        uniforms[name] = gl.getUniformLocation(program, name);
      }
      return uniforms;
    }

    class Material {
      constructor(vs, fsSource) {
        this.vertexShader        = vs;
        this.fragmentShaderSource = fsSource;
        this.programs            = [];
        this.activeProgram       = null;
        this.uniforms            = [];
      }
      setKeywords(keywords) {
        let hash = 0;
        for (let i = 0; i < keywords.length; i++) hash += hashCode(keywords[i]);
        let program = this.programs[hash];
        if (!program) {
          const fs = compileShader(gl.FRAGMENT_SHADER, this.fragmentShaderSource, keywords);
          program  = createProgram(this.vertexShader, fs);
          this.programs[hash] = program;
        }
        if (program === this.activeProgram) return;
        this.uniforms      = getUniforms(program);
        this.activeProgram = program;
      }
      bind() { gl.useProgram(this.activeProgram); }
    }

    class GLProgram {
      constructor(vs, fs) {
        this.program  = createProgram(vs, fs);
        this.uniforms = getUniforms(this.program);
      }
      bind() { gl.useProgram(this.program); }
    }

    /* ── Shaders ── */
    const baseVS = compileShader(gl.VERTEX_SHADER, `
      precision highp float;
      attribute vec2 aPosition;
      varying vec2 vUv;varying vec2 vL;varying vec2 vR;varying vec2 vT;varying vec2 vB;
      uniform vec2 texelSize;
      void main(){
        vUv=aPosition*0.5+0.5;
        vL=vUv-vec2(texelSize.x,0.0);vR=vUv+vec2(texelSize.x,0.0);
        vT=vUv+vec2(0.0,texelSize.y);vB=vUv-vec2(0.0,texelSize.y);
        gl_Position=vec4(aPosition,0.0,1.0);
      }
    `);

    const copyShader = compileShader(gl.FRAGMENT_SHADER, `
      precision mediump float;precision mediump sampler2D;
      varying highp vec2 vUv;uniform sampler2D uTexture;
      void main(){gl_FragColor=texture2D(uTexture,vUv);}
    `);

    const clearShader = compileShader(gl.FRAGMENT_SHADER, `
      precision mediump float;precision mediump sampler2D;
      varying highp vec2 vUv;uniform sampler2D uTexture;uniform float value;
      void main(){gl_FragColor=value*texture2D(uTexture,vUv);}
    `);

    const displayShaderSource = `
      precision highp float;precision highp sampler2D;
      varying vec2 vUv;varying vec2 vL;varying vec2 vR;varying vec2 vT;varying vec2 vB;
      uniform sampler2D uTexture;uniform vec2 texelSize;
      vec3 linearToGamma(vec3 c){c=max(c,vec3(0));return max(1.055*pow(c,vec3(0.416666667))-0.055,vec3(0));}
      void main(){
        vec3 c=texture2D(uTexture,vUv).rgb;
        #ifdef SHADING
          vec3 lc=texture2D(uTexture,vL).rgb;vec3 rc=texture2D(uTexture,vR).rgb;
          vec3 tc=texture2D(uTexture,vT).rgb;vec3 bc=texture2D(uTexture,vB).rgb;
          float dx=length(rc)-length(lc);float dy=length(tc)-length(bc);
          vec3 n=normalize(vec3(dx,dy,length(texelSize)));vec3 l=vec3(0.0,0.0,1.0);
          float diffuse=clamp(dot(n,l)+0.7,0.7,1.0);c*=diffuse;
        #endif
        float a=max(c.r,max(c.g,c.b));
        gl_FragColor=vec4(c,a);
      }
    `;

    const splatShader = compileShader(gl.FRAGMENT_SHADER, `
      precision highp float;precision highp sampler2D;
      varying vec2 vUv;uniform sampler2D uTarget;
      uniform float aspectRatio;uniform vec3 color;uniform vec2 point;uniform float radius;
      void main(){
        vec2 p=vUv-point.xy;p.x*=aspectRatio;
        vec3 splat=exp(-dot(p,p)/radius)*color;
        vec3 base=texture2D(uTarget,vUv).xyz;
        gl_FragColor=vec4(base+splat,1.0);
      }
    `);

    const advectionShader = compileShader(gl.FRAGMENT_SHADER, `
      precision highp float;precision highp sampler2D;
      varying vec2 vUv;uniform sampler2D uVelocity;uniform sampler2D uSource;
      uniform vec2 texelSize;uniform vec2 dyeTexelSize;uniform float dt;uniform float dissipation;
      vec4 bilerp(sampler2D sam,vec2 uv,vec2 tsize){
        vec2 st=uv/tsize-0.5;vec2 iuv=floor(st);vec2 fuv=fract(st);
        vec4 a=texture2D(sam,(iuv+vec2(0.5,0.5))*tsize);
        vec4 b=texture2D(sam,(iuv+vec2(1.5,0.5))*tsize);
        vec4 c=texture2D(sam,(iuv+vec2(0.5,1.5))*tsize);
        vec4 d=texture2D(sam,(iuv+vec2(1.5,1.5))*tsize);
        return mix(mix(a,b,fuv.x),mix(c,d,fuv.x),fuv.y);
      }
      void main(){
        #ifdef MANUAL_FILTERING
          vec2 coord=vUv-dt*bilerp(uVelocity,vUv,texelSize).xy*texelSize;
          vec4 result=bilerp(uSource,coord,dyeTexelSize);
        #else
          vec2 coord=vUv-dt*texture2D(uVelocity,vUv).xy*texelSize;
          vec4 result=texture2D(uSource,coord);
        #endif
        float decay=1.0+dissipation*dt;
        gl_FragColor=result/decay;
      }
    `, ext.supportLinearFiltering ? null : ['MANUAL_FILTERING']);

    const divergenceShader = compileShader(gl.FRAGMENT_SHADER, `
      precision mediump float;precision mediump sampler2D;
      varying highp vec2 vUv;varying highp vec2 vL;varying highp vec2 vR;
      varying highp vec2 vT;varying highp vec2 vB;uniform sampler2D uVelocity;
      void main(){
        float L=texture2D(uVelocity,vL).x;float R=texture2D(uVelocity,vR).x;
        float T=texture2D(uVelocity,vT).y;float B=texture2D(uVelocity,vB).y;
        vec2 C=texture2D(uVelocity,vUv).xy;
        if(vL.x<0.0){L=-C.x;}if(vR.x>1.0){R=-C.x;}
        if(vT.y>1.0){T=-C.y;}if(vB.y<0.0){B=-C.y;}
        float div=0.5*(R-L+T-B);
        gl_FragColor=vec4(div,0.0,0.0,1.0);
      }
    `);

    const curlShader = compileShader(gl.FRAGMENT_SHADER, `
      precision mediump float;precision mediump sampler2D;
      varying highp vec2 vUv;varying highp vec2 vL;varying highp vec2 vR;
      varying highp vec2 vT;varying highp vec2 vB;uniform sampler2D uVelocity;
      void main(){
        float L=texture2D(uVelocity,vL).y;float R=texture2D(uVelocity,vR).y;
        float T=texture2D(uVelocity,vT).x;float B=texture2D(uVelocity,vB).x;
        float vorticity=R-L-T+B;
        gl_FragColor=vec4(0.5*vorticity,0.0,0.0,1.0);
      }
    `);

    const vorticityShader = compileShader(gl.FRAGMENT_SHADER, `
      precision highp float;precision highp sampler2D;
      varying vec2 vUv;varying vec2 vL;varying vec2 vR;varying vec2 vT;varying vec2 vB;
      uniform sampler2D uVelocity;uniform sampler2D uCurl;uniform float curl;uniform float dt;
      void main(){
        float L=texture2D(uCurl,vL).x;float R=texture2D(uCurl,vR).x;
        float T=texture2D(uCurl,vT).x;float B=texture2D(uCurl,vB).x;
        float C=texture2D(uCurl,vUv).x;
        vec2 force=0.5*vec2(abs(T)-abs(B),abs(R)-abs(L));
        force/=length(force)+0.0001;force*=curl*C;force.y*=-1.0;
        vec2 velocity=texture2D(uVelocity,vUv).xy;
        velocity+=force*dt;velocity=min(max(velocity,-1000.0),1000.0);
        gl_FragColor=vec4(velocity,0.0,1.0);
      }
    `);

    const pressureShader = compileShader(gl.FRAGMENT_SHADER, `
      precision mediump float;precision mediump sampler2D;
      varying highp vec2 vUv;varying highp vec2 vL;varying highp vec2 vR;
      varying highp vec2 vT;varying highp vec2 vB;
      uniform sampler2D uPressure;uniform sampler2D uDivergence;
      void main(){
        float L=texture2D(uPressure,vL).x;float R=texture2D(uPressure,vR).x;
        float T=texture2D(uPressure,vT).x;float B=texture2D(uPressure,vB).x;
        float divergence=texture2D(uDivergence,vUv).x;
        float pressure=(L+R+B+T-divergence)*0.25;
        gl_FragColor=vec4(pressure,0.0,0.0,1.0);
      }
    `);

    const gradientSubtractShader = compileShader(gl.FRAGMENT_SHADER, `
      precision mediump float;precision mediump sampler2D;
      varying highp vec2 vUv;varying highp vec2 vL;varying highp vec2 vR;
      varying highp vec2 vT;varying highp vec2 vB;
      uniform sampler2D uPressure;uniform sampler2D uVelocity;
      void main(){
        float L=texture2D(uPressure,vL).x;float R=texture2D(uPressure,vR).x;
        float T=texture2D(uPressure,vT).x;float B=texture2D(uPressure,vB).x;
        vec2 velocity=texture2D(uVelocity,vUv).xy;
        velocity.xy-=vec2(R-L,T-B);
        gl_FragColor=vec4(velocity,0.0,1.0);
      }
    `);

    /* ── Blit quad ── */
    const blit = (() => {
      gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1,-1,1,1,1,1,-1]), gl.STATIC_DRAW);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, gl.createBuffer());
      gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array([0,1,2,0,2,3]), gl.STATIC_DRAW);
      gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
      gl.enableVertexAttribArray(0);
      return function (target, clear) {
        if (target == null) {
          gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight);
          gl.bindFramebuffer(gl.FRAMEBUFFER, null);
        } else {
          gl.viewport(0, 0, target.width, target.height);
          gl.bindFramebuffer(gl.FRAMEBUFFER, target.fbo);
        }
        if (clear) { gl.clearColor(0,0,0,1); gl.clear(gl.COLOR_BUFFER_BIT); }
        gl.drawElements(gl.TRIANGLES, 6, gl.UNSIGNED_SHORT, 0);
      };
    })();

    /* ── Programs ── */
    const copyProgram            = new GLProgram(baseVS, copyShader);
    const clearProgram           = new GLProgram(baseVS, clearShader);
    const splatProgram           = new GLProgram(baseVS, splatShader);
    const advectionProgram       = new GLProgram(baseVS, advectionShader);
    const divergenceProgram      = new GLProgram(baseVS, divergenceShader);
    const curlProgram            = new GLProgram(baseVS, curlShader);
    const vorticityProgram       = new GLProgram(baseVS, vorticityShader);
    const pressureProgram        = new GLProgram(baseVS, pressureShader);
    const gradienSubtractProgram = new GLProgram(baseVS, gradientSubtractShader);
    const displayMaterial        = new Material(baseVS, displayShaderSource);

    /* ── FBOs ── */
    let dye, velocity, divergence, curl, pressure;

    function createFBO(w, h, internalFormat, format, type, param) {
      gl.activeTexture(gl.TEXTURE0);
      const texture = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, texture);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, param);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, param);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, internalFormat, w, h, 0, format, type, null);
      const fbo = gl.createFramebuffer();
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
      gl.viewport(0, 0, w, h);
      gl.clear(gl.COLOR_BUFFER_BIT);
      return {
        texture, fbo, width: w, height: h,
        texelSizeX: 1 / w, texelSizeY: 1 / h,
        attach(id) {
          gl.activeTexture(gl.TEXTURE0 + id);
          gl.bindTexture(gl.TEXTURE_2D, texture);
          return id;
        }
      };
    }

    function createDoubleFBO(w, h, internalFormat, format, type, param) {
      let fbo1 = createFBO(w, h, internalFormat, format, type, param);
      let fbo2 = createFBO(w, h, internalFormat, format, type, param);
      return {
        width: w, height: h,
        texelSizeX: fbo1.texelSizeX, texelSizeY: fbo1.texelSizeY,
        get read()  { return fbo1; },
        set read(v) { fbo1 = v; },
        get write() { return fbo2; },
        set write(v){ fbo2 = v; },
        swap() { let t = fbo1; fbo1 = fbo2; fbo2 = t; }
      };
    }

    function resizeFBO(target, w, h, internalFormat, format, type, param) {
      const newFBO = createFBO(w, h, internalFormat, format, type, param);
      copyProgram.bind();
      gl.uniform1i(copyProgram.uniforms.uTexture, target.attach(0));
      blit(newFBO);
      return newFBO;
    }

    function resizeDoubleFBO(target, w, h, internalFormat, format, type, param) {
      if (target.width === w && target.height === h) return target;
      target.read  = resizeFBO(target.read, w, h, internalFormat, format, type, param);
      target.write = createFBO(w, h, internalFormat, format, type, param);
      target.width = w; target.height = h;
      target.texelSizeX = 1 / w; target.texelSizeY = 1 / h;
      return target;
    }

    function initFramebuffers() {
      const simRes  = getResolution(config.SIM_RESOLUTION);
      const dyeRes  = getResolution(config.DYE_RESOLUTION);
      const texType = ext.halfFloatTexType;
      const rgba    = ext.formatRGBA;
      const rg      = ext.formatRG;
      const r       = ext.formatR;
      const filtering = ext.supportLinearFiltering ? gl.LINEAR : gl.NEAREST;
      gl.disable(gl.BLEND);

      dye      = dye      ? resizeDoubleFBO(dye,      dyeRes.width,  dyeRes.height,  rgba.internalFormat, rgba.format, texType, filtering)
                          : createDoubleFBO(dyeRes.width,  dyeRes.height,  rgba.internalFormat, rgba.format, texType, filtering);
      velocity = velocity ? resizeDoubleFBO(velocity, simRes.width,  simRes.height,  rg.internalFormat,   rg.format,   texType, filtering)
                          : createDoubleFBO(simRes.width,  simRes.height,  rg.internalFormat,   rg.format,   texType, filtering);

      divergence = createFBO(simRes.width, simRes.height, r.internalFormat, r.format, texType, gl.NEAREST);
      curl       = createFBO(simRes.width, simRes.height, r.internalFormat, r.format, texType, gl.NEAREST);
      pressure   = createDoubleFBO(simRes.width, simRes.height, r.internalFormat, r.format, texType, gl.NEAREST);
    }

    function updateKeywords() {
      const kw = [];
      if (config.SHADING) kw.push('SHADING');
      displayMaterial.setKeywords(kw);
    }

    updateKeywords();
    initFramebuffers();

    let lastUpdateTime   = Date.now();
    let colorUpdateTimer = 0;

    /* ── Animation loop ── */
    function updateFrame() {
      const dt = calcDeltaTime();
      if (resizeCanvas()) initFramebuffers();
      updateColors(dt);
      applyInputs();
      step(dt);
      render(null);
      animFrameId = requestAnimationFrame(updateFrame);
    }

    function calcDeltaTime() {
      const now = Date.now();
      let dt = (now - lastUpdateTime) / 1000;
      dt = Math.min(dt, 0.016666);
      lastUpdateTime = now;
      return dt;
    }

    function resizeCanvas() {
      const w = scaleByPixelRatio(canvas.clientWidth);
      const h = scaleByPixelRatio(canvas.clientHeight);
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w; canvas.height = h;
        return true;
      }
      return false;
    }

    function updateColors(dt) {
      colorUpdateTimer += dt * config.COLOR_UPDATE_SPEED;
      if (colorUpdateTimer >= 1) {
        colorUpdateTimer = wrap(colorUpdateTimer, 0, 1);
        pointers.forEach(p => { p.color = generateColor(); });
      }
    }

    function applyInputs() {
      pointers.forEach(p => {
        if (p.moved) { p.moved = false; splatPointer(p); }
      });
    }

    function step(dt) {
      gl.disable(gl.BLEND);

      curlProgram.bind();
      gl.uniform2f(curlProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
      gl.uniform1i(curlProgram.uniforms.uVelocity, velocity.read.attach(0));
      blit(curl);

      vorticityProgram.bind();
      gl.uniform2f(vorticityProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
      gl.uniform1i(vorticityProgram.uniforms.uVelocity, velocity.read.attach(0));
      gl.uniform1i(vorticityProgram.uniforms.uCurl,     curl.attach(1));
      gl.uniform1f(vorticityProgram.uniforms.curl,      config.CURL);
      gl.uniform1f(vorticityProgram.uniforms.dt,        dt);
      blit(velocity.write); velocity.swap();

      divergenceProgram.bind();
      gl.uniform2f(divergenceProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
      gl.uniform1i(divergenceProgram.uniforms.uVelocity, velocity.read.attach(0));
      blit(divergence);

      clearProgram.bind();
      gl.uniform1i(clearProgram.uniforms.uTexture, pressure.read.attach(0));
      gl.uniform1f(clearProgram.uniforms.value,    config.PRESSURE);
      blit(pressure.write); pressure.swap();

      pressureProgram.bind();
      gl.uniform2f(pressureProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
      gl.uniform1i(pressureProgram.uniforms.uDivergence, divergence.attach(0));
      for (let i = 0; i < config.PRESSURE_ITERATIONS; i++) {
        gl.uniform1i(pressureProgram.uniforms.uPressure, pressure.read.attach(1));
        blit(pressure.write); pressure.swap();
      }

      gradienSubtractProgram.bind();
      gl.uniform2f(gradienSubtractProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
      gl.uniform1i(gradienSubtractProgram.uniforms.uPressure, pressure.read.attach(0));
      gl.uniform1i(gradienSubtractProgram.uniforms.uVelocity, velocity.read.attach(1));
      blit(velocity.write); velocity.swap();

      advectionProgram.bind();
      gl.uniform2f(advectionProgram.uniforms.texelSize, velocity.texelSizeX, velocity.texelSizeY);
      if (!ext.supportLinearFiltering)
        gl.uniform2f(advectionProgram.uniforms.dyeTexelSize, velocity.texelSizeX, velocity.texelSizeY);
      const velId = velocity.read.attach(0);
      gl.uniform1i(advectionProgram.uniforms.uVelocity,   velId);
      gl.uniform1i(advectionProgram.uniforms.uSource,     velId);
      gl.uniform1f(advectionProgram.uniforms.dt,          dt);
      gl.uniform1f(advectionProgram.uniforms.dissipation, config.VELOCITY_DISSIPATION);
      blit(velocity.write); velocity.swap();

      if (!ext.supportLinearFiltering)
        gl.uniform2f(advectionProgram.uniforms.dyeTexelSize, dye.texelSizeX, dye.texelSizeY);
      gl.uniform1i(advectionProgram.uniforms.uVelocity, velocity.read.attach(0));
      gl.uniform1i(advectionProgram.uniforms.uSource,   dye.read.attach(1));
      gl.uniform1f(advectionProgram.uniforms.dissipation, config.DENSITY_DISSIPATION);
      blit(dye.write); dye.swap();
    }

    function render(target) {
      gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
      gl.enable(gl.BLEND);
      drawDisplay(target);
    }

    function drawDisplay(target) {
      const w = target == null ? gl.drawingBufferWidth  : target.width;
      const h = target == null ? gl.drawingBufferHeight : target.height;
      displayMaterial.bind();
      if (config.SHADING) gl.uniform2f(displayMaterial.uniforms.texelSize, 1 / w, 1 / h);
      gl.uniform1i(displayMaterial.uniforms.uTexture, dye.read.attach(0));
      blit(target);
    }

    /* ── Splat helpers ── */
    function splatPointer(ptr) {
      const dx = ptr.deltaX * config.SPLAT_FORCE;
      const dy = ptr.deltaY * config.SPLAT_FORCE;
      splat(ptr.texcoordX, ptr.texcoordY, dx, dy, ptr.color);
    }

    function clickSplat(ptr) {
      const color = generateColor();
      color.r *= 10; color.g *= 10; color.b *= 10;
      const dx = 10 * (Math.random() - 0.5);
      const dy = 30 * (Math.random() - 0.5);
      splat(ptr.texcoordX, ptr.texcoordY, dx, dy, color);
    }

    function splat(x, y, dx, dy, color) {
      splatProgram.bind();
      gl.uniform1i(splatProgram.uniforms.uTarget,     velocity.read.attach(0));
      gl.uniform1f(splatProgram.uniforms.aspectRatio, canvas.width / canvas.height);
      gl.uniform2f(splatProgram.uniforms.point,       x, y);
      gl.uniform3f(splatProgram.uniforms.color,       dx, dy, 0);
      gl.uniform1f(splatProgram.uniforms.radius,      correctRadius(config.SPLAT_RADIUS / 100));
      blit(velocity.write); velocity.swap();

      gl.uniform1i(splatProgram.uniforms.uTarget, dye.read.attach(0));
      gl.uniform3f(splatProgram.uniforms.color, color.r, color.g, color.b);
      blit(dye.write); dye.swap();
    }

    function correctRadius(radius) {
      const ar = canvas.width / canvas.height;
      if (ar > 1) radius *= ar;
      return radius;
    }

    /* ── Pointer update helpers ── */
    function updatePointerDownData(ptr, id, posX, posY) {
      ptr.id = id; ptr.down = true; ptr.moved = false;
      ptr.texcoordX = posX / canvas.width;
      ptr.texcoordY = 1 - posY / canvas.height;
      ptr.prevTexcoordX = ptr.texcoordX;
      ptr.prevTexcoordY = ptr.texcoordY;
      ptr.deltaX = 0; ptr.deltaY = 0;
      ptr.color = generateColor();
    }

    function updatePointerMoveData(ptr, posX, posY, color) {
      ptr.prevTexcoordX = ptr.texcoordX;
      ptr.prevTexcoordY = ptr.texcoordY;
      ptr.texcoordX = posX / canvas.width;
      ptr.texcoordY = 1 - posY / canvas.height;
      ptr.deltaX = correctDeltaX(ptr.texcoordX - ptr.prevTexcoordX);
      ptr.deltaY = correctDeltaY(ptr.texcoordY - ptr.prevTexcoordY);
      ptr.moved  = Math.abs(ptr.deltaX) > 0 || Math.abs(ptr.deltaY) > 0;
      ptr.color  = color;
    }

    function updatePointerUpData(ptr) { ptr.down = false; }

    function correctDeltaX(delta) {
      const ar = canvas.width / canvas.height;
      if (ar < 1) delta *= ar;
      return delta;
    }

    function correctDeltaY(delta) {
      const ar = canvas.width / canvas.height;
      if (ar > 1) delta /= ar;
      return delta;
    }

    /* ── Color generation ── */
    function hexToRGB(hex) {
      let val = hex.replace('#', '');
      if (val.length === 3) val = val[0]+val[0]+val[1]+val[1]+val[2]+val[2];
      const r = parseInt(val.slice(0,2), 16) / 255;
      const g = parseInt(val.slice(2,4), 16) / 255;
      const b = parseInt(val.slice(4,6), 16) / 255;
      return { r: r * 0.15, g: g * 0.15, b: b * 0.15 };
    }

    function generateColor() {
      if (!config.RAINBOW_MODE) return hexToRGB(config.COLOR);
      const c = HSVtoRGB(Math.random(), 1, 1);
      c.r *= 0.15; c.g *= 0.15; c.b *= 0.15;
      return c;
    }

    function HSVtoRGB(h, s, v) {
      let r, g, b;
      const i = Math.floor(h * 6);
      const f = h * 6 - i;
      const p = v * (1 - s);
      const q = v * (1 - f * s);
      const t = v * (1 - (1 - f) * s);
      switch (i % 6) {
        case 0: r=v; g=t; b=p; break;
        case 1: r=q; g=v; b=p; break;
        case 2: r=p; g=v; b=t; break;
        case 3: r=p; g=q; b=v; break;
        case 4: r=t; g=p; b=v; break;
        case 5: r=v; g=p; b=q; break;
        default: r=g=b=0;
      }
      return { r, g, b };
    }

    /* ── Utility ── */
    function wrap(val, min, max) {
      const range = max - min;
      if (range === 0) return min;
      return ((val - min) % range) + min;
    }

    function getResolution(resolution) {
      let ar = gl.drawingBufferWidth / gl.drawingBufferHeight;
      if (ar < 1) ar = 1 / ar;
      const min = Math.round(resolution);
      const max = Math.round(resolution * ar);
      return gl.drawingBufferWidth > gl.drawingBufferHeight
        ? { width: max, height: min }
        : { width: min, height: max };
    }

    function scaleByPixelRatio(input) {
      return Math.floor(input * (window.devicePixelRatio || 1));
    }

    function hashCode(s) {
      let hash = 0;
      for (let i = 0; i < s.length; i++) {
        hash = (hash << 5) - hash + s.charCodeAt(i);
        hash |= 0;
      }
      return hash;
    }

    /* ── Event listeners ── */
    let firstMouseMoveHandled = false;

    function onMouseDown(e) {
      const ptr  = pointers[0];
      const posX = scaleByPixelRatio(e.clientX);
      const posY = scaleByPixelRatio(e.clientY);
      updatePointerDownData(ptr, -1, posX, posY);
      clickSplat(ptr);
    }

    function onMouseMove(e) {
      const ptr   = pointers[0];
      const posX  = scaleByPixelRatio(e.clientX);
      const posY  = scaleByPixelRatio(e.clientY);
      const color = firstMouseMoveHandled ? ptr.color : generateColor();
      firstMouseMoveHandled = true;
      updatePointerMoveData(ptr, posX, posY, color);
    }

    function onTouchStart(e) {
      const touches = e.targetTouches;
      const ptr     = pointers[0];
      for (let i = 0; i < touches.length; i++) {
        updatePointerDownData(ptr, touches[i].identifier,
          scaleByPixelRatio(touches[i].clientX),
          scaleByPixelRatio(touches[i].clientY));
      }
    }

    function onTouchMove(e) {
      const touches = e.targetTouches;
      const ptr     = pointers[0];
      for (let i = 0; i < touches.length; i++) {
        updatePointerMoveData(ptr,
          scaleByPixelRatio(touches[i].clientX),
          scaleByPixelRatio(touches[i].clientY),
          ptr.color);
      }
    }

    function onTouchEnd(e) {
      const touches = e.changedTouches;
      const ptr     = pointers[0];
      for (let i = 0; i < touches.length; i++) updatePointerUpData(ptr);
    }

    window.addEventListener('mousedown',  onMouseDown);
    window.addEventListener('mousemove',  onMouseMove);
    window.addEventListener('touchstart', onTouchStart);
    window.addEventListener('touchmove',  onTouchMove, { passive: true });
    window.addEventListener('touchend',   onTouchEnd);

    /* ── Kick off ── */
    updateFrame();
  }

  /* ── Auto-init ── */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { initSplashCursor(); });
  } else {
    initSplashCursor();
  }

})();
